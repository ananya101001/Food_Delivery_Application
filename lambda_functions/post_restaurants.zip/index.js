const mysql = require('mysql2/promise');

let connection;

exports.handler = async (event) => {
    // Extract data from the POST request body
    const body = event.body ? JSON.parse(event.body) : null;
    console.log(body)

    if (!body) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Invalid or missing JSON body" }),
        };
    }

    const { name, address, phone_number, cuisine_type, rating } = body;

    // Database connection parameters
    if (!connection) {
        console.log("Opening DB connection...");
        connection = await mysql.createConnection({
            host: 'food-delivery-db.cl4yg086473r.us-west-1.rds.amazonaws.com',  // RDS endpoint
            user: 'ananya',  // Username
            password: 'UberSecretPassword',  // Password
            database: 'fooddeliverydb',  // Database name
        });
    }

    try {
        // Insert a new restaurant into the database
        const [result] = await connection.execute(
            'INSERT INTO restaurants (name, address, phone_number, cuisine_type, rating) VALUES (?, ?, ?, ?, ?)',
            [
                name,
                address,
                phone_number || null,    // If not provided, pass null
                cuisine_type || null,     // If not provided, pass null
                rating || null            // If not provided, pass null
            ]
        );

        return {
            statusCode: 201,
            headers: {
                'Access-Control-Allow-Origin': '*', // Replace with your frontend origin in production
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ message: 'Restaurant added successfully', id: result.insertId }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
        };
    } finally {
    }
};

