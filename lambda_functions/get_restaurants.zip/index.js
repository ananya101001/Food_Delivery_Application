const mysql = require('mysql2/promise');
let connection;

exports.handler = async (event) => {
    try {
        // Initialize DB connection if not already done
        if (!connection) {
            console.log("Opening DB connection...");
            connection = await mysql.createConnection({
                host: 'food-delivery-db.cl4yg086473r.us-west-1.rds.amazonaws.com',  // RDS endpoint
                user: 'ananya',  // Username
                password: 'UberSecretPassword',  // Password
                database: 'fooddeliverydb',  // Database name
            });
        }

        console.log("Executing database query...");
        // Example: Query all restaurants
        const [rows] = await connection.execute('SELECT * FROM restaurants');
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',  // Or specify your frontend's origin
                'Access-Control-Allow-Credentials': true,
                'Content-Type': 'application/json'
            },
            
            body: JSON.stringify(rows),
        };

    } catch (error) {
        console.error("Error:", error.message);
        // Return a custom error message
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error: ' + error.message }),
        };
    } finally {
        // Ensure to close the connection after execution
        if (connection) {
            try {
                
                console.log('Database connection closed.');
            } catch (err) {
                console.error('Error closing database connection: ', err.message);
            }
        }
    }
};

