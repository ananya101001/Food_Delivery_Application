const mysql = require('mysql2/promise');

exports.handler = async (event) => {
    const body = event.body ? JSON.parse(event.body) : {};
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        database: process.env.DB_NAME,
    });

    try {
        const [rows] = await connection.execute('SELECT * FROM menu');
        return {
            statusCode: 200,
            body: JSON.stringify(rows),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
        };
    } finally {
        connection.end();
    }
};
