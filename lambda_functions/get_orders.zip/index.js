const mysql = require('mysql2/promise');

let connection;

exports.handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Extract customer_id from query parameters
    const customerId = event.queryStringParameters ? event.queryStringParameters.customer_id : null;

    if (!customerId) {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ error: "Missing customer_id parameter" }),
        };
    }

    // Database connection parameters
    if (!connection) {
        console.log("Opening DB connection...");
        connection = await mysql.createConnection({
            host: 'food-delivery-db.cl4yg086473r.us-west-1.rds.amazonaws.com',
            user: 'ananya',
            password: 'UberSecretPassword',
            database: 'fooddeliverydb',
        });
    }

    try {
        // Query to get orders for the specified customer
        const [rows] = await connection.execute(
            'SELECT * FROM orders WHERE customer_id = ?',
            [customerId]
        );

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify(rows),
        };
    } catch (error) {
        console.error("Error fetching orders:", error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ error: "Failed to fetch orders: " + error.message }),
        };
    } finally {
        if (connection) {
            await connection.end();
        }
    }
};