const mysql = require('mysql2/promise');

let connection;

exports.handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Extract data from the POST request body
    const body = event.body ? JSON.parse(event.body) : null;

    if (!body || !body.restaurant_id || !body.items || !Array.isArray(body.items)) {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ error: "Invalid or missing JSON body. Ensure restaurant_id and items array are provided." }),
        };
    }

    const { restaurant_id, items } = body;

    // Database connection parameters
    if (!connection) {
        console.log("Opening DB connection...");
        connection = await mysql.createConnection({
            host: 'food-delivery-db.cl4yg086473r.us-west-1.rds.amazonaws.com',
            user: 'ananya',
            password: 'UberSecretPassword',
            database: 'fooddeliverydb',
        });
    }

    try {
        // Start a transaction
        await connection.beginTransaction();

        // Insert menu items
        for (const item of items) {
            await connection.execute(
                'INSERT INTO menu_items (restaurant_id, name, description, price) VALUES (?, ?, ?, ?)',
                [restaurant_id, item.name, item.description, item.price]
            );
        }

        // Commit the transaction
        await connection.commit();

        return {
            statusCode: 201,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ message: 'Menu items added successfully', restaurant_id: restaurant_id }),
        };
    } catch (error) {
        // If there's an error, rollback the transaction
        await connection.rollback();

        console.error("Error adding menu items:", error);

        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ error: "Failed to add menu items: " + error.message }),
        };
    } finally {
        if (connection) {
            
            await connection.end();
        }
    }
};